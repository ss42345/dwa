<form method='POST' action='/posts/p_add'>

	<strong>New Post:</strong><br>
	<textarea class="postwindow" name='content'></textarea>

	<br><br>
	<input type="submit" value="Post Message" style="position:absolute; top:250px; left: 5%;">

</form>